class Config:
    SQLALCHEMY_DATABASE_URI = 'postgresql://myuser:mypassword@localhost/mydb'
    SQLALCHEMY_TRACK_MODIFICATIONS = False